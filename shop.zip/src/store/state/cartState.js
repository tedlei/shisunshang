export default {
    state:{
        cartdata: [
            {
              storename: '富锦旗舰店',
              goodslist: [
                {
                  goodsmsg: '富锦年货特产坚果零食大礼包万事如意混合坚果公司送礼盒装',
                 goodsimg: '../../../../assets/img/pei1.png',
                  goodsspecs: '100*10',
                  goodsprice: '98'
                },
                {
                  goodsmsg: '富锦年货特产坚果零食大礼包万事如意混合坚果公司送礼盒装',
                  goodsimg: '../../../../assets/img/pei1.png',
                  goodsspecs: '100*10',
                  goodsprice: '98'
                }
              ]
            },
            {
              storename: '富锦旗舰店',
              goodslist: [
                {
                  goodsmsg: '富锦年货特产坚果零食大礼包万事如意混合坚果公司送礼盒装',
                  goodsimg: '../../../../assets/img/pei1.png',
                  goodsspecs: '100*10',
                  goodsprice: '98'
                }
              ]
            }
        ],
        getshops:{},
        goodsData:{}
    }
}