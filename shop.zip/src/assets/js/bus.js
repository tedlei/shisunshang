import Vue from 'vue'

var Bus = new Vue();
export default Bus;
