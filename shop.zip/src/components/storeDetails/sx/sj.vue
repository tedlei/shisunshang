<template>
    <div>
        <span>综合</span>
        <img src="../../../assets/img/xsj.png" alt="">
    </div>
</template>

<script>
  export default {
  components: {},
  data () {
    return {
      
    }
  },
  methods: {
    
  },
  computed: {
    
  },
  watch: {
    
  }
}
</script>
<style lang="scss" scoped>
  
</style>