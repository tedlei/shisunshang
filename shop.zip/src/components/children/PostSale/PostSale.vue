<template>
    $END$
</template>

<script>
    export default {
        name: "PostSale"
    }
</script>

<style scoped>

</style>
