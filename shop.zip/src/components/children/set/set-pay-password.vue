<template>
  <div>
    <set-bang></set-bang>
  </div>
</template>

<script>
    import SetBang from "./set-bang";
    export default {
        name: "set-pay-password",
        components: {SetBang},
        data() {
            return {

            }
        },
        methods: {

        }
    }
</script>

<style scoped lang="scss">

</style>
