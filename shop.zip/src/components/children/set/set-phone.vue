<template>
  <set-bang></set-bang>
</template>

<script>
    import SetBang from "./set-bang";
    export default {
        name: "set-phone",
        components: {SetBang}
    }
</script>

<style scoped>

</style>
