<template>
    <div>

    </div>
</template>

<script>
    export default {
        name: "list"
    }
</script>

<style scoped>

</style>
