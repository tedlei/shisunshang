<template>

</template>

<script>
    export default {
        name: "Financial-records"
    }
</script>

<style scoped>

</style>
